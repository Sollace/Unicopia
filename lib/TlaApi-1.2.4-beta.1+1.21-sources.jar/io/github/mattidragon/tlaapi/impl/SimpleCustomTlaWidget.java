package io.github.mattidragon.tlaapi.impl;

import io.github.mattidragon.tlaapi.api.gui.CustomTlaWidget;
import io.github.mattidragon.tlaapi.api.gui.TlaBounds;
import net.minecraft.class_332;
import net.minecraft.class_4068;

public class SimpleCustomTlaWidget implements CustomTlaWidget {
    private final class_4068 widget;
    private final TlaBounds bounds;

    public SimpleCustomTlaWidget(class_4068 widget, TlaBounds bounds) {
        this.widget = widget;
        this.bounds = bounds;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        widget.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public TlaBounds getBounds() {
        return bounds;
    }
}
